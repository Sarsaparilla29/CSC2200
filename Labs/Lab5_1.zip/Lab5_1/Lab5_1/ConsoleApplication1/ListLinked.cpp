
#include "ListLinked.h"

// ListNode member functions

template <typename DataType>
List<DataType>::ListNode::ListNode(const DataType& nodeData, ListNode* nextPtr)
{
	this->dataItem = nodeData;
	this->next = nextPtr;
}

// List member functions

template <typename DataType>
List<DataType>::List(int ignored)
{
}

template <typename DataType>
List<DataType>::List(const List& other)
{
}

template <typename DataType>
List<DataType>& List<DataType>::operator=(const List& other)
{
}

template <typename DataType>
List<DataType>::~List()
{
}

template <typename DataType>
void List<DataType>::insert(const DataType& newDataItem) throw (logic_error)
{
}

template <typename DataType>
void List<DataType>::remove() throw (logic_error)
{
}

template <typename DataType>
void List<DataType>::replace(const DataType& newDataItem) throw (logic_error)
{
}

template <typename DataType>
void List<DataType>::clear()
{
}

template <typename DataType>
bool List<DataType>::isEmpty() const
{
	return false;
}

template <typename DataType>
bool List<DataType>::isFull() const
{
	return false;
}

template <typename DataType>
void List<DataType>::gotoBeginning() throw (logic_error)
{
}

template <typename DataType>
void List<DataType>::gotoEnd() throw (logic_error)
{
}

template <typename DataType>
bool List<DataType>::gotoNext() throw (logic_error)
{
	return false;
}

template <typename DataType>
bool List<DataType>::gotoPrior() throw (logic_error)
{
	return false;
}

template <typename DataType>
DataType List<DataType>::getCursor() const throw (logic_error)
{
	DataType t = NULL;
	return t;
}

template <typename DataType>
void List<DataType>::moveToBeginning() throw (logic_error)
{
}

template <typename DataType>
void List<DataType>::insertBefore(const DataType& newDataItem) throw (logic_error)
{
}

#include "show5.cpp"

